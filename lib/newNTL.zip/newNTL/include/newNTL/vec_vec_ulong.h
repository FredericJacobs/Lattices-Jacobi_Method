
#ifndef newNTL_vec_vec_ulong__H
#define newNTL_vec_vec_ulong__H

#include <newNTL/vec_ulong.h>

newNTL_OPEN_NNS

newNTL_vector_decl(vec_ulong,vec_vec_ulong)

newNTL_eq_vector_decl(vec_ulong,vec_vec_ulong)

newNTL_io_vector_decl(vec_ulong,vec_vec_ulong)

newNTL_CLOSE_NNS


#endif
