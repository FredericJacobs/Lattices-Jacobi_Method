
#ifndef newNTL_vec_vec_RR__H
#define newNTL_vec_vec_RR__H

#include <newNTL/vec_RR.h>

newNTL_OPEN_NNS

newNTL_vector_decl(vec_RR,vec_vec_RR)

newNTL_eq_vector_decl(vec_RR,vec_vec_RR)

newNTL_io_vector_decl(vec_RR,vec_vec_RR)

newNTL_CLOSE_NNS

#endif
