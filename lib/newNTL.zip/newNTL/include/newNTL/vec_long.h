
#ifndef newNTL_vec_long__H
#define newNTL_vec_long__H

#include <newNTL/vector.h>

newNTL_OPEN_NNS

newNTL_vector_decl(long,vec_long)

newNTL_io_vector_decl(long,vec_long)

newNTL_eq_vector_decl(long,vec_long)

newNTL_CLOSE_NNS

#endif
