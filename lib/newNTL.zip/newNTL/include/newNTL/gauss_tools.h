#ifndef GAUSSIAN_HEURISTIC_H
#define GAUSSIAN_HEURISTIC_H

#ifndef PLANTE
#define PLANTE(errormsg) { \
cerr << errormsg << "at line " << __LINE__ << endl; \
cout << errormsg << "at line " << __LINE__ << endl; \
abort(); }
#endif


#include <newNTL/RR.h>
#include <newNTL/ZZ.h>
#include <newNTL/mat_RR.h>
#include <newNTL/vec_RR.h>
#include <newNTL/tools.h>
#include <newNTL/gso.h>
#include <sstream>
#include <string>
#include <cmath>

newNTL_OPEN_NNS
namespace{
  static __thread istringstream* GAUSS_TOOLS_global_iss = 0;  
  template <typename T>
    istringstream& operator>>(const std::string& s,T& obj)
    {
      if (GAUSS_TOOLS_global_iss) delete GAUSS_TOOLS_global_iss;
      GAUSS_TOOLS_global_iss = new istringstream (s);
      *(GAUSS_TOOLS_global_iss) >> obj;
      return *(GAUSS_TOOLS_global_iss);
    }  
}

// Computes \log(\Gamma(i/2))
// Caches results for faster calculation
inline RR LogGammaIs2(long i)
{
  RR R_PI; string("3.14159265358979323846264338328") >> R_PI;
  static vec_RR lgam;
  static int imax=-1;
  if (imax==-1) { // do first time only
    lgam.SetLength(1000);
    lgam(2)=0.;
    lgam(1)=log(R_PI)/to_RR(2);
    imax=2;
  }
  if (imax>=i) return lgam(i);
  for (int j=imax+1;j<=i;j++) {
    lgam(j)= lgam(j-2) + log(to_RR(j/2.-1.));
  }
  imax=i;
  return lgam(i);
}

// Computes the radius of the ball of volume 1 in n dimensions
inline RR Gauss_rn(long n)
{
  RR R_PI; string("3.14159265358979323846264338328") >> R_PI;
  return exp((LogGammaIs2(n+2)-to_RR(n/2.)*log(R_PI))/to_RR(n));
}


// Computes the *square* radius of the ball of volume 1 in n dimensions
inline RR Gauss_rn2(long n)
{
  RR R_PI; string("3.14159265358979323846264338328") >> R_PI;
  return exp(LogGammaIs2(n+2)/to_RR(n/2.) - log(R_PI));
}

// Returns log(Volume(UnitBall(n)))
inline RR Gauss_logVn(long n)
{
  RR R_PI; string("3.14159265358979323846264338328") >> R_PI;
  return -LogGammaIs2(n+2)+to_RR(n/2.)*log(R_PI);
}    

// Sample a real number with Gaussian distribution
inline void Gauss_random(RR& r)
{
  RR u_1,u_2,v_1,v_2,un,s,t;

  conv(un,1);

  do {
    random(u_1);
    random(u_2);
    add(t,u_1,u_1);
    sub(v_1,t,un); /* v_1 = random in [-1,1] */
    add(t,u_2,u_2);
    sub(v_2,t,un); /* v_2 = random in [-1,1] */
    sqr(t,v_1);
    sqr(s,v_2);
    add(s,t,s); /* s = v_1^2+v_2^2 */
  }
  while (s >= un);

  t = -2*log(s)/s;
  SqrRoot(s,t); /* s = sqrt(-2log(s)/s)*/
  mul(r,v_1,s);
}

inline void GaussianSample(RR& res,const RR& param) {
  static RR invsqrt2Pi(INIT_VAL,"0.39894228040143267793994605993438186847");
  Gauss_random(res);
  res *= param;
  res *= invsqrt2Pi;
}

inline RR GaussianSample_RR(const RR& param) {
  RR t;
  GaussianSample(t,param);
  return t;
}

inline void GaussianSample(ZZ& res,const RR& param, const RR& center) {
  RR r;
  GaussianSample(r,param);
  r+=center;
  RoundToZZ(res,r);
}

inline ZZ GaussianSample_ZZ(const RR& param, const RR& center) {
  ZZ t;
  GaussianSample(t,param,center);
  return t;
}

struct RealCoset {
  long n;
  long m;
  mat_RR Bp1;
  mat_RR mu;
  vec_RR C;

  RealCoset(const mat_ZZ& B, const vec_RR& center) {
    m = B.NumCols();
    n=B.NumRows();
    Bp1.SetDims(n+1,m+1);
    for (long i=1; i<=n; i++)
      for (long j=1; j<=m; j++)
        Bp1(i,j)=B(i,j);
    for (long i=1; i<=n; i++)
      Bp1(i,m+1)=0;
    Bp1(n+1,m+1)=1e80;
    for (long j=1; j<=m; j++)
      Bp1(n+1,j)=center(j);
    GSO<RR> gso;
    LQ_householder(Bp1,gso);
    sizeReduction_householder(Bp1,gso);
    mu = gso.get_mu();
    C = gso.get_C();
  }
};

struct IntegerCoset {
  long n;
  long m;
  mat_ZZ Bp1;
  mat_RR mu;
  vec_RR C;

  IntegerCoset(
      const mat_ZZ& B, 
      const vec_ZZ& center) 
  {
    m = B.NumCols();
    n=B.NumRows();
    Bp1.SetDims(n+1,m+1);
    for (long i=1; i<=n; i++)
      for (long j=1; j<=m; j++)
        Bp1(i,j)=B(i,j);
    for (long i=1; i<=n; i++)
      Bp1(i,m+1)=0;
    Bp1(n+1,m+1)=1l<<62;
    for (long j=1; j<=m; j++)
      Bp1(n+1,j)=center(j);
    GSO<RR> gso;
    LQ_householder(Bp1,gso);
    sizeReduction_householder(Bp1,gso);
    mu = gso.get_mu();
    C = gso.get_C();
  }
};


inline void GaussianSample_Coset(
    vec_RR& res, 
    const RealCoset& cp, 
    const RR& param) 
{
  long n = cp.n;
  long m = cp.m;  
  vec_RR out; out.SetLength(n+1);
  clear(out); out(n+1)=1;
  for (int j=n; j>0; j--) {
    //calculer l'oppose du projete de la combinaison courante sur bj*
    RR c = 0;
    for (int i=j+1; i<=n+1; i++) c-= out(i)*cp.mu(i,j);
    //sampler un entier gaussien autour de c
    conv(out(j),GaussianSample_ZZ(param/sqrt(cp.C(j)),c));
  }
  res = out * cp.Bp1;
  res.SetLength(m);
}

inline void GaussianSample_Coset(
    vec_ZZ& res, 
    const IntegerCoset& cp, 
    const RR& param) 
{
  long n = cp.n;
  long m = cp.m;  
  vec_ZZ out; out.SetLength(n+1);
  clear(out); out(n+1)=1;
  for (int j=n; j>0; j--) {
    //calculer l'oppose du projete de la combinaison courante sur bj*
    RR c = 0;
    for (int i=j+1; i<=n+1; i++) c-= out(i)*cp.mu(i,j);
    //sampler un entier gaussien autour de c
    out(j)=GaussianSample_ZZ(param/sqrt(cp.C(j)),c);
  }
  res = out * cp.Bp1;
  res.SetLength(m);
}


// Choose a uniformly random vector from the n dimensional sphere
// First chooses a Gaussian vectors and then normalizes
inline void Sphere_random(vec_RR & v, long n)
{
  RR norm_v,un,norm2;
  long i;

  v.SetLength(n);

  for (i=1;i<=n;i++) {
    Gauss_random(v(i));
  }
  InnerProduct(norm_v,v,v);
  SqrRoot(norm2,norm_v);
  inv(un,norm2);
  mul(v,v,un);
}

// Choose a uniformly random vector from the n dimensional ball
// First chooses a Gaussian vectors and then normalizes
inline void Ball_random(vec_RR & v, long n)
{
  RR u; u=random_RR();
  u=pow(u,to_RR(1./n));
  Sphere_random(v,n);
  v=u*v;
}

newNTL_CLOSE_NNS

#endif // GAUSSIAN_HEURISTIC_H
