
#ifndef newNTL_vec_double__H
#define newNTL_vec_double__H

#include <newNTL/vector.h>

newNTL_OPEN_NNS

newNTL_vector_decl(double,vec_double)

newNTL_io_vector_decl(double,vec_double)

newNTL_eq_vector_decl(double,vec_double)

newNTL_CLOSE_NNS

#endif
