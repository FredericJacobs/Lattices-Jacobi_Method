
#ifndef newNTL_vec_ulong__H
#define newNTL_vec_ulong__H

#include <newNTL/vector.h>

newNTL_OPEN_NNS

newNTL_vector_decl(_newntl_ulong,vec_ulong)

newNTL_io_vector_decl(_newntl_ulong,vec_ulong)

newNTL_eq_vector_decl(_newntl_ulong,vec_ulong)

newNTL_CLOSE_NNS

#endif
