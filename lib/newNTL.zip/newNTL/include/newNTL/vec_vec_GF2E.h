
#ifndef newNTL_vec_vec_GF2E__H
#define newNTL_vec_vec_GF2E__H

#include <newNTL/vec_GF2E.h>

newNTL_OPEN_NNS

newNTL_vector_decl(vec_GF2E,vec_vec_GF2E)

newNTL_eq_vector_decl(vec_GF2E,vec_vec_GF2E)

newNTL_io_vector_decl(vec_GF2E,vec_vec_GF2E)

newNTL_CLOSE_NNS

#endif
