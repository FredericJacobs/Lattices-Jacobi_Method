
#ifndef newNTL_version__H
#define newNTL_version__H

#define newNTL_VERSION "5.5.2"

#define newNTL_MAJOR_VERSION  (5)
#define newNTL_MINOR_VERSION  (5)
#define newNTL_REVISION       (2)

#endif

