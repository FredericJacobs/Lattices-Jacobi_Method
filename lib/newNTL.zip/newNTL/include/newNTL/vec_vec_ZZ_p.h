
#ifndef newNTL_vec_vec_ZZ_p__H
#define newNTL_vec_vec_ZZ_p__H

#include <newNTL/vec_ZZ_p.h>

newNTL_OPEN_NNS

newNTL_vector_decl(vec_ZZ_p,vec_vec_ZZ_p)

newNTL_eq_vector_decl(vec_ZZ_p,vec_vec_ZZ_p)

newNTL_io_vector_decl(vec_ZZ_p,vec_vec_ZZ_p)

newNTL_CLOSE_NNS

#endif
