
#ifndef newNTL_vec_vec_long__H
#define newNTL_vec_vec_long__H

#include <newNTL/vec_long.h>

newNTL_OPEN_NNS

newNTL_vector_decl(vec_long,vec_vec_long)

newNTL_eq_vector_decl(vec_long,vec_vec_long)

newNTL_io_vector_decl(vec_long,vec_vec_long)

newNTL_CLOSE_NNS


#endif
