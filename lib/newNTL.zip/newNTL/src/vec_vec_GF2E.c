
#include <newNTL/vec_vec_GF2E.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_GF2E,vec_vec_GF2E)

newNTL_eq_vector_impl(vec_GF2E,vec_vec_GF2E)

newNTL_io_vector_impl(vec_GF2E,vec_vec_GF2E)

newNTL_END_IMPL
