
#include <newNTL/vec_GF2XVec.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(GF2XVec,vec_GF2XVec)

newNTL_END_IMPL
