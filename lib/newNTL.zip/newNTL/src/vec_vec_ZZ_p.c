
#include <newNTL/vec_vec_ZZ_p.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_ZZ_p,vec_vec_ZZ_p)

newNTL_eq_vector_impl(vec_ZZ_p,vec_vec_ZZ_p)

newNTL_io_vector_impl(vec_ZZ_p,vec_vec_ZZ_p)

newNTL_END_IMPL
