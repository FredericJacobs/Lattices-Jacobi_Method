
#include <newNTL/vec_vec_ZZ_pE.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_ZZ_pE,vec_vec_ZZ_pE)

newNTL_eq_vector_impl(vec_ZZ_pE,vec_vec_ZZ_pE)

newNTL_io_vector_impl(vec_ZZ_pE,vec_vec_ZZ_pE)

newNTL_END_IMPL
