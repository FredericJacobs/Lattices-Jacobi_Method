
#include <newNTL/vec_vec_ZZ.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_ZZ,vec_vec_ZZ)

newNTL_eq_vector_impl(vec_ZZ,vec_vec_ZZ)

newNTL_io_vector_impl(vec_ZZ,vec_vec_ZZ)

newNTL_END_IMPL

