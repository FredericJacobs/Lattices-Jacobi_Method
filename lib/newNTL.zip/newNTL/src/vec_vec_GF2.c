
#include <newNTL/vec_vec_GF2.h>

#include <newNTL/new.h>

newNTL_START_IMPL


newNTL_vector_impl(vec_GF2,vec_vec_GF2)

newNTL_eq_vector_impl(vec_GF2,vec_vec_GF2)

newNTL_io_vector_impl(vec_GF2,vec_vec_GF2)

newNTL_END_IMPL

