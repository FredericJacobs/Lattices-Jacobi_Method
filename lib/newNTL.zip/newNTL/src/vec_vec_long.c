
#include <newNTL/vec_vec_long.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_long,vec_vec_long)

newNTL_eq_vector_impl(vec_long,vec_vec_long)

newNTL_io_vector_impl(vec_long,vec_vec_long)


newNTL_END_IMPL
