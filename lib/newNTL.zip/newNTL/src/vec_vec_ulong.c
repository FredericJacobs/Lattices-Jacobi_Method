
#include <newNTL/vec_vec_ulong.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_ulong,vec_vec_ulong)

newNTL_eq_vector_impl(vec_ulong,vec_vec_ulong)

newNTL_io_vector_impl(vec_ulong,vec_vec_ulong)


newNTL_END_IMPL
