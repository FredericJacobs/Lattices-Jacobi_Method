#include <newNTL/LLL.h>

newNTL_CLIENT;

int main() {
    RR x = 1;
    RR y = 2.;
    ZZ p = 5;
    cout << exp(5+x) << endl;
    cout << log(3+exp(5+p)) << endl;
    
}


