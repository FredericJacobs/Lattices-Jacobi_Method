#include <newNTL/LLL.h>

newNTL_CLIENT;

int main() {
    ZZ x = 1;
    ZZ y = 2;
    cout << x << "+" << y << "=" << x+y << endl;
}


