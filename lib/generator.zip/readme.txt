run "make generate_random"

Syntax: "./generate_random [--dim 80] [--seed 0]"