
#include <newNTL/vec_quad_float.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(quad_float,vec_quad_float)

newNTL_io_vector_impl(quad_float,vec_quad_float)

newNTL_eq_vector_impl(quad_float,vec_quad_float)

newNTL_END_IMPL

