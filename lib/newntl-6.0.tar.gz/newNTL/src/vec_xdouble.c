
#include <newNTL/vec_xdouble.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(xdouble,vec_xdouble)

newNTL_io_vector_impl(xdouble,vec_xdouble)

newNTL_eq_vector_impl(xdouble,vec_xdouble)

newNTL_END_IMPL
