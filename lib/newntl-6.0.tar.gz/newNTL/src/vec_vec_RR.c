
#include <newNTL/vec_vec_RR.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_RR,vec_vec_RR)

newNTL_eq_vector_impl(vec_RR,vec_vec_RR)

newNTL_io_vector_impl(vec_RR,vec_vec_RR)

newNTL_END_IMPL

