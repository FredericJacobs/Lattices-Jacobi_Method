
#include <newNTL/vec_vec_lzz_p.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(vec_zz_p,vec_vec_zz_p)

newNTL_eq_vector_impl(vec_zz_p,vec_vec_zz_p)

newNTL_io_vector_impl(vec_zz_p,vec_vec_zz_p)

newNTL_END_IMPL
