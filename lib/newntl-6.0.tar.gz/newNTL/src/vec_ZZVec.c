
#include <newNTL/vec_ZZVec.h>

#include <newNTL/new.h>

newNTL_START_IMPL

newNTL_vector_impl(ZZVec,vec_ZZVec)

newNTL_END_IMPL
