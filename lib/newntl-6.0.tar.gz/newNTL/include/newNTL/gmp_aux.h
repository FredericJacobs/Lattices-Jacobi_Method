#define newNTL_ZZ_NBITS (64)
#define newNTL_ZZ_FRADIX (((double)(1L<<62))*((double)(1L<<2)))
