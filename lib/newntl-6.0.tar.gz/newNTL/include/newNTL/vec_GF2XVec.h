
#ifndef newNTL_vec_GF2XVec__H
#define newNTL_vec_GF2XVec__H

#include <newNTL/vector.h>
#include <newNTL/GF2XVec.h>

newNTL_OPEN_NNS

newNTL_vector_decl(GF2XVec,vec_GF2XVec)

newNTL_CLOSE_NNS

#endif
