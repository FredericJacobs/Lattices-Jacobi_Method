
#ifndef newNTL_vec_ZZVec__H
#define newNTL_vec_ZZVec__H

#include <newNTL/vector.h>
#include <newNTL/ZZVec.h>

newNTL_OPEN_NNS

newNTL_vector_decl(ZZVec,vec_ZZVec)

newNTL_CLOSE_NNS

#endif
