
#ifndef newNTL_g_lip__H
#define newNTL_g_lip__H

#include <newNTL/config.h>
#include <newNTL/mach_desc.h>

#ifdef newNTL_GMP_LIP

#include <newNTL/gmp_aux.h>

#include <newNTL/g_lip.h>

#else

#include <newNTL/c_lip.h>

#endif

#endif
